def test_assert_values():
    assert 1 == 1
