# Release Notes

## 0.1.0 - Initial Release

### Features

- Implemented `GridGenerator`
- Implemented `GeometryValidation`
- Implemented `VectorZonalStats`
